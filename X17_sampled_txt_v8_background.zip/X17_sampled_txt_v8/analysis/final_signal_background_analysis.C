#include <TFile.h>
#include <TTree.h>
#include <TH1D.h>
#include <TMath.h>
#include <TString.h>

#include <cmath>
#include <iostream>

namespace
{
TTree* get_tree(TFile& f, const char* treeName)
{
    auto* t = dynamic_cast<TTree*>(f.Get(treeName));
    if (!t) {
        std::cerr << "ERROR: cannot find tree `" << treeName << "` in "
                  << f.GetName() << std::endl;
    }
    return t;
}

TH1D* make_hist(const char* name,
                const char* title,
                int nbins,
                double xmin,
                double xmax)
{
    auto* h = new TH1D(name, title, nbins, xmin, xmax);
    h->Sumw2();
    return h;
}

void project_checked(TTree* t, TH1D* h, const char* expression)
{
    if (!t || !h) return;
    const Long64_t n = t->Project(h->GetName(), expression, "");
    if (n < 0) {
        std::cerr << "WARNING: failed to project expression `" << expression
                  << "` into " << h->GetName() << std::endl;
    }
}

TH1D* normalized_clone(const TH1D* h, const char* name)
{
    auto* out = dynamic_cast<TH1D*>(h->Clone(name));
    if (out->Integral() > 0.0) out->Scale(1.0 / out->Integral());
    return out;
}

TH1D* significance_hist(const TH1D* hs, const TH1D* hb, const char* name, const char* title)
{
    auto* h = dynamic_cast<TH1D*>(hs->Clone(name));
    h->SetTitle(title);
    h->Reset("ICES");

    for (int i = 1; i <= hs->GetNbinsX(); ++i) {
        const double s = hs->GetBinContent(i);
        const double b = hb->GetBinContent(i);
        const double z = (b > 0.0) ? s / std::sqrt(b) : 0.0;
        h->SetBinContent(i, z);
        h->SetBinError(i, 0.0);
    }
    return h;
}

void print_best_bins(const TH1D* hSig, const TH1D* hBkg, const char* label)
{
    double bestSoverB = -1.0;
    double bestZ = -1.0;
    int bestBinSoverB = -1;
    int bestBinZ = -1;

    for (int i = 1; i <= hSig->GetNbinsX(); ++i) {
        const double s = hSig->GetBinContent(i);
        const double b = hBkg->GetBinContent(i);
        const double soverb = (b > 0.0) ? s / b : 0.0;
        const double z = (b > 0.0) ? s / std::sqrt(b) : 0.0;
        if (soverb > bestSoverB) { bestSoverB = soverb; bestBinSoverB = i; }
        if (z > bestZ) { bestZ = z; bestBinZ = i; }
    }

    auto print_one = [&](const char* metric, double val, int bin) {
        if (bin <= 0) return;
        std::cout << "Best " << metric << " in " << label << ": "
                  << val << " around ["
                  << hSig->GetXaxis()->GetBinLowEdge(bin) << ", "
                  << hSig->GetXaxis()->GetBinUpEdge(bin) << "]\n";
    };

    print_one("S/B", bestSoverB, bestBinSoverB);
    print_one("S/sqrt(B)", bestZ, bestBinZ);
}
}

void final_signal_background_analysis(const char* signalDetectorEffectsFile = "analysis_hits_detector_effects.root",
                                      const char* backgroundDetectorEffectsFile = "background_analysis_hits_detector_effects.root",
                                      const char* outputFile = "final_signal_background.root",
                                      double signalScale = 1.0,
                                      double backgroundScale = 1.0)
{
    // Input files must contain a tree named `detected_detector_effects`, produced
    // by analysis/apply_detector_effects.C. This macro does not modify either
    // input. It only produces template histograms and simple S/B diagnostics.

    TFile fs(signalDetectorEffectsFile, "READ");
    if (fs.IsZombie()) {
        std::cerr << "ERROR: cannot open signal file: " << signalDetectorEffectsFile << std::endl;
        return;
    }
    TFile fb(backgroundDetectorEffectsFile, "READ");
    if (fb.IsZombie()) {
        std::cerr << "ERROR: cannot open background file: " << backgroundDetectorEffectsFile << std::endl;
        return;
    }

    TTree* ts = get_tree(fs, "detected_detector_effects");
    TTree* tb = get_tree(fb, "detected_detector_effects");
    if (!ts || !tb) return;

    TFile fout(outputFile, "RECREATE");

    auto* hThetaRecoS = make_hist("hThetaEE_reco_signal", "Signal;#theta_{ee}^{reco} [deg];Events", 180, 0, 180);
    auto* hThetaRecoB = make_hist("hThetaEE_reco_background", "Background;#theta_{ee}^{reco} [deg];Events", 180, 0, 180);
    auto* hThetaHitS  = make_hist("hThetaEE_hit_signal", "Signal ideal detected;#theta_{ee}^{hit} [deg];Events", 180, 0, 180);
    auto* hThetaHitB  = make_hist("hThetaEE_hit_background", "Background ideal detected;#theta_{ee}^{hit} [deg];Events", 180, 0, 180);
    auto* hThetaGenS  = make_hist("hThetaEE_gen_signal", "Signal generator-level for detected events;#theta_{ee}^{gen} [deg];Events", 180, 0, 180);
    auto* hThetaGenB  = make_hist("hThetaEE_gen_background", "Background generator-level for detected events;#theta_{ee}^{gen} [deg];Events", 180, 0, 180);

    auto* hEnergyRecoS = make_hist("hEnergyEE_reco_signal", "Signal;T_{e-}^{reco}+T_{e+}^{reco} [MeV];Events", 220, 0, 22);
    auto* hEnergyRecoB = make_hist("hEnergyEE_reco_background", "Background;T_{e-}^{reco}+T_{e+}^{reco} [MeV];Events", 220, 0, 22);
    auto* hMassRecoS = make_hist("hMassEE_reco_signal", "Signal;m_{ee}^{reco} [MeV/c^{2}];Events", 220, 0, 22);
    auto* hMassRecoB = make_hist("hMassEE_reco_background", "Background;m_{ee}^{reco} [MeV/c^{2}];Events", 220, 0, 22);

    project_checked(ts, hThetaRecoS, "thetaEE_reco_deg");
    project_checked(tb, hThetaRecoB, "thetaEE_reco_deg");
    project_checked(ts, hThetaHitS,  "thetaEE_hit_deg");
    project_checked(tb, hThetaHitB,  "thetaEE_hit_deg");
    project_checked(ts, hThetaGenS,  "thetaEE_txt_deg");
    project_checked(tb, hThetaGenB,  "thetaEE_txt_deg");
    project_checked(ts, hEnergyRecoS, "energyEE_reco_MeV");
    project_checked(tb, hEnergyRecoB, "energyEE_reco_MeV");
    project_checked(ts, hMassRecoS, "massEE_reco_MeV");
    project_checked(tb, hMassRecoB, "massEE_reco_MeV");

    // Scale to arbitrary expected yields. Defaults leave raw reconstructed event counts.
    hThetaRecoS->Scale(signalScale);
    hThetaHitS->Scale(signalScale);
    hThetaGenS->Scale(signalScale);
    hEnergyRecoS->Scale(signalScale);
    hMassRecoS->Scale(signalScale);

    hThetaRecoB->Scale(backgroundScale);
    hThetaHitB->Scale(backgroundScale);
    hThetaGenB->Scale(backgroundScale);
    hEnergyRecoB->Scale(backgroundScale);
    hMassRecoB->Scale(backgroundScale);

    auto* hThetaRecoSB = dynamic_cast<TH1D*>(hThetaRecoB->Clone("hThetaEE_reco_signal_plus_background"));
    hThetaRecoSB->SetTitle("Signal + background;#theta_{ee}^{reco} [deg];Events");
    hThetaRecoSB->Add(hThetaRecoS);

    auto* hMassRecoSB = dynamic_cast<TH1D*>(hMassRecoB->Clone("hMassEE_reco_signal_plus_background"));
    hMassRecoSB->SetTitle("Signal + background;m_{ee}^{reco} [MeV/c^{2}];Events");
    hMassRecoSB->Add(hMassRecoS);

    auto* hThetaRecoSShape = normalized_clone(hThetaRecoS, "hThetaEE_reco_signal_shape");
    auto* hThetaRecoBShape = normalized_clone(hThetaRecoB, "hThetaEE_reco_background_shape");
    auto* hMassRecoSShape = normalized_clone(hMassRecoS, "hMassEE_reco_signal_shape");
    auto* hMassRecoBShape = normalized_clone(hMassRecoB, "hMassEE_reco_background_shape");

    auto* hThetaSignificance = significance_hist(hThetaRecoS, hThetaRecoB,
                                                 "hThetaEE_reco_S_over_sqrtB",
                                                 "Bin-by-bin S/#sqrt{B};#theta_{ee}^{reco} [deg];S/#sqrt{B}");
    auto* hMassSignificance = significance_hist(hMassRecoS, hMassRecoB,
                                                "hMassEE_reco_S_over_sqrtB",
                                                "Bin-by-bin S/#sqrt{B};m_{ee}^{reco} [MeV/c^{2}];S/#sqrt{B}");

    hThetaRecoS->Write();
    hThetaRecoB->Write();
    hThetaRecoSB->Write();
    hThetaRecoSShape->Write();
    hThetaRecoBShape->Write();
    hThetaSignificance->Write();

    hThetaHitS->Write();
    hThetaHitB->Write();
    hThetaGenS->Write();
    hThetaGenB->Write();

    hEnergyRecoS->Write();
    hEnergyRecoB->Write();
    hMassRecoS->Write();
    hMassRecoB->Write();
    hMassRecoSB->Write();
    hMassRecoSShape->Write();
    hMassRecoBShape->Write();
    hMassSignificance->Write();

    fout.Close();

    std::cout << "\n=== Final signal/background analysis summary ===\n";
    std::cout << "Signal detector-effects file     : " << signalDetectorEffectsFile << "\n";
    std::cout << "Background detector-effects file : " << backgroundDetectorEffectsFile << "\n";
    std::cout << "Output file                      : " << outputFile << "\n";
    std::cout << "Signal reconstructed entries     : " << ts->GetEntries() << "  scale = " << signalScale << "\n";
    std::cout << "Background reconstructed entries : " << tb->GetEntries() << "  scale = " << backgroundScale << "\n";
    std::cout << "Scaled signal yield              : " << hThetaRecoS->Integral() << "\n";
    std::cout << "Scaled background yield          : " << hThetaRecoB->Integral() << "\n";
    print_best_bins(hThetaRecoS, hThetaRecoB, "thetaEE_reco_deg");
    print_best_bins(hMassRecoS, hMassRecoB, "massEE_reco_MeV");
    std::cout << "Histograms written for thetaEE, energy sum, invariant mass, templates and S/sqrt(B).\n";
    std::cout << "================================================\n";
}
