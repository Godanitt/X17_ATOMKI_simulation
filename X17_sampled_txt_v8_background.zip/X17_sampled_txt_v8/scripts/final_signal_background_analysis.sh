#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

SIGNAL_INPUT="${1:-${PROJECT_DIR}/analysis_hits_detector_effects.root}"
BACKGROUND_INPUT="${2:-${PROJECT_DIR}/background_analysis_hits_detector_effects.root}"
OUTPUT="${3:-${PROJECT_DIR}/final_signal_background.root}"
SIGNAL_SCALE="${4:-1.0}"
BACKGROUND_SCALE="${5:-1.0}"

if ! command -v root >/dev/null 2>&1; then
  echo "ERROR: ROOT executable not found in PATH." >&2
  exit 2
fi

if [[ ! -f "${SIGNAL_INPUT}" ]]; then
  echo "ERROR: signal detector-effects ROOT file not found: ${SIGNAL_INPUT}" >&2
  exit 2
fi

if [[ ! -f "${BACKGROUND_INPUT}" ]]; then
  echo "ERROR: background detector-effects ROOT file not found: ${BACKGROUND_INPUT}" >&2
  exit 2
fi

cd "${PROJECT_DIR}"
root -l -b -q "analysis/final_signal_background_analysis.C(\"${SIGNAL_INPUT}\",\"${BACKGROUND_INPUT}\",\"${OUTPUT}\",${SIGNAL_SCALE},${BACKGROUND_SCALE})"
