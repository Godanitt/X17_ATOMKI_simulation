#!/usr/bin/env bash
set -Eeuo pipefail

# Build the Geant4 executable. The executable supports all predefined geometries
# at runtime, so this script builds once and can optionally launch the viewer with
# the requested geometry.
#
# Usage:
#   bash scripts/build.sh [current|2pi|4pi|padplane] [--vis]
#   bash scripts/build.sh --geometry 4pi --vis

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
BUILD_DIR="${PROJECT_DIR}/build"
INPUT="${PROJECT_DIR}/data/data_pair_creation.txt"

GEOMETRY="current"
RUN_VIS=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --geometry|--geom)
      GEOMETRY="${2:-}"
      shift 2
      ;;
    --vis)
      RUN_VIS=1
      shift
      ;;
    current|baseline|atomki|2pi|coverage2pi|4pi|coverage4pi|padplane|pad_plane|pads|frontpads)
      GEOMETRY="$1"
      shift
      ;;
    -h|--help)
      sed -n '1,16p' "$0"
      exit 0
      ;;
    *)
      echo "ERROR: unknown argument: $1" >&2
      exit 2
      ;;
  esac
done

cd "${PROJECT_DIR}"

if [[ -f "${BUILD_DIR}/CMakeCache.txt" ]] && ! grep -q "CMAKE_HOME_DIRECTORY:INTERNAL=${PROJECT_DIR}" "${BUILD_DIR}/CMakeCache.txt"; then
  echo "Removing stale build directory from a different source path: ${BUILD_DIR}"
  rm -rf "${BUILD_DIR}"
fi

mkdir -p "${BUILD_DIR}"

if [[ ! -f "${INPUT}" ]]; then
  echo "ERROR: input data table not found: ${INPUT}" >&2
  exit 2
fi

echo "=== Building X17 simulation ==="
echo "Project dir : ${PROJECT_DIR}"
echo "Build dir   : ${BUILD_DIR}"
echo "Geometry    : ${GEOMETRY}"
echo

cmake -S "${PROJECT_DIR}" -B "${BUILD_DIR}" -DCMAKE_BUILD_TYPE=Release
cmake --build "${BUILD_DIR}" --parallel "$(nproc)"

if [[ "${RUN_VIS}" == "1" ]]; then
  echo
  echo "=== Launching visualization for geometry: ${GEOMETRY} ==="
  "${BUILD_DIR}/x17sim" --vis --geometry "${GEOMETRY}" -i "${INPUT}" -o "${PROJECT_DIR}/sampled.root"
else
  echo
  echo "Build complete: ${BUILD_DIR}/x17sim"
  echo "Run visualization with: bash scripts/build.sh ${GEOMETRY} --vis"
fi
