#!/usr/bin/env bash
# x17_full_analysis.sh
#
# Wrapper for analysis/x17_full_analysis.C
#
# Default usage from the project root:
#
#   bash scripts/x17_full_analysis.sh
#
# Full usage:
#
#   bash scripts/x17_full_analysis.sh \
#     sampled.root \
#     background_sampled.root \
#     analysis_hits.root \
#     background_analysis_hits.root \
#     analysis_hits_detector_effects.root \
#     background_analysis_hits_detector_effects.root \
#     x17_final_analysis.root \
#     plots \
#     0 \
#     1.0 \
#     1.0
#
# Arguments:
#   1  signal sampled ROOT file
#   2  background sampled ROOT file
#   3  signal ideal analysis ROOT file
#   4  background ideal analysis ROOT file
#   5  signal detector-effects ROOT file
#   6  background detector-effects ROOT file
#   7  output ROOT file
#   8  output plot directory
#   9  selected volumeID: 0 SiliconStripLV, 1 ScintillatorLV, -1 any volume
#   10 signal scale
#   11 background scale

set -euo pipefail

# Resolve project root. This allows running either from the project root
# or directly from scripts/.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

cd "${PROJECT_DIR}"

SIG_SAMPLED="${1:-sampled.root}"
BKG_SAMPLED="${2:-background_sampled.root}"
SIG_IDEAL="${3:-analysis_hits.root}"
BKG_IDEAL="${4:-background_analysis_hits.root}"
SIG_RECO="${5:-analysis_hits_detector_effects.root}"
BKG_RECO="${6:-background_analysis_hits_detector_effects.root}"
OUT_ROOT="${7:-x17_final_analysis.root}"
OUT_DIR="${8:-plots}"
VOLUME_ID="${9:-0}"
SIGNAL_SCALE="${10:-1.0}"
BACKGROUND_SCALE="${11:-1.0}"

MACRO="analysis/x17_full_analysis.C"

if ! command -v root >/dev/null 2>&1; then
    echo "[ERROR] ROOT is not available in PATH."
    echo "        Source your ROOT environment first."
    exit 1
fi

if [[ ! -f "${MACRO}" ]]; then
    echo "[ERROR] Missing macro: ${MACRO}"
    echo "        Copy x17_full_analysis.C into the analysis/ directory."
    exit 1
fi

for file in \
    "${SIG_SAMPLED}" \
    "${BKG_SAMPLED}" \
    "${SIG_IDEAL}" \
    "${BKG_IDEAL}" \
    "${SIG_RECO}" \
    "${BKG_RECO}"
do
    if [[ ! -f "${file}" ]]; then
        echo "[ERROR] Missing input file: ${file}"
        exit 1
    fi
done

mkdir -p "${OUT_DIR}"

echo "=== Running final X17 signal/background analysis ==="
echo "Signal sampled file          : ${SIG_SAMPLED}"
echo "Background sampled file      : ${BKG_SAMPLED}"
echo "Signal ideal analysis file   : ${SIG_IDEAL}"
echo "Background ideal file        : ${BKG_IDEAL}"
echo "Signal detector-effects file : ${SIG_RECO}"
echo "Background detector file     : ${BKG_RECO}"
echo "Output ROOT file             : ${OUT_ROOT}"
echo "Output plot directory        : ${OUT_DIR}"
echo "Selected volumeID            : ${VOLUME_ID}"
echo "Signal scale                 : ${SIGNAL_SCALE}"
echo "Background scale             : ${BACKGROUND_SCALE}"
echo

root -l -q "${MACRO}(\"${SIG_SAMPLED}\",\"${BKG_SAMPLED}\",\"${SIG_IDEAL}\",\"${BKG_IDEAL}\",\"${SIG_RECO}\",\"${BKG_RECO}\",\"${OUT_ROOT}\",\"${OUT_DIR}\",${VOLUME_ID},${SIGNAL_SCALE},${BACKGROUND_SCALE})"

echo
echo "=== Done ==="
echo "Output ROOT file : ${OUT_ROOT}"
echo "Plots directory  : ${OUT_DIR}"
