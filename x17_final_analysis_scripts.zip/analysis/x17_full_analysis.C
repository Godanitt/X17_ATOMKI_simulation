// x17_full_analysis.C
//
// ROOT macro to summarize the full X17 analysis chain:
//
//   signal_sampled.root/background_sampled.root
//      generated + hits
//
//   signal_analysis_hits.root/background_analysis_hits.root
//      detected
//
//   signal_analysis_hits_detector_effects.root/background_analysis_hits_detector_effects.root
//      detected_detector_effects
//
// Usage from ROOT:
//
//   root -l -q 'analysis/x17_full_analysis.C(
//       "sampled.root",
//       "background_sampled.root",
//       "analysis_hits.root",
//       "background_analysis_hits.root",
//       "analysis_hits_detector_effects.root",
//       "background_analysis_hits_detector_effects.root",
//       "x17_final_analysis.root",
//       "plots",
//       0,
//       1.0,
//       1.0
//   )'
//
// Arguments:
//   sigSampled        : signal sampled ROOT file with generated + hits
//   bkgSampled        : background sampled ROOT file with generated + hits
//   sigIdeal          : signal ideal analysis ROOT file with detected
//   bkgIdeal          : background ideal analysis ROOT file with detected
//   sigReco           : signal detector-effects ROOT file with detected_detector_effects
//   bkgReco           : background detector-effects ROOT file with detected_detector_effects
//   outRoot           : output ROOT file
//   outDir            : directory for PDF plots
//   volumeID          : hit volume selection, e.g. 0 = SiliconStripLV, 1 = ScintillatorLV, -1 = any
//   signalScale       : scale factor applied to signal histograms
//   backgroundScale   : scale factor applied to background histograms

#include <TFile.h>
#include <TTree.h>
#include <TBranch.h>
#include <TH1D.h>
#include <TCanvas.h>
#include <TLegend.h>
#include <TStyle.h>
#include <TSystem.h>
#include <TLatex.h>
#include <TMath.h>

#include <iostream>
#include <iomanip>
#include <string>
#include <set>
#include <vector>
#include <memory>
#include <algorithm>

namespace x17ana {

bool HasBranch(TTree* tree, const char* name) {
    return tree && tree->GetBranch(name);
}

TTree* GetTreeChecked(TFile* file, const char* treeName, const std::string& fileName) {
    if (!file || file->IsZombie()) {
        std::cerr << "[ERROR] Cannot open file: " << fileName << std::endl;
        return nullptr;
    }
    TTree* tree = dynamic_cast<TTree*>(file->Get(treeName));
    if (!tree) {
        std::cerr << "[ERROR] Missing tree '" << treeName << "' in file: " << fileName << std::endl;
    }
    return tree;
}

struct AcceptanceSummary {
    Long64_t nGenerated = 0;
    Long64_t nHitRowsSelected = 0;
    Long64_t nElectronEvents = 0;
    Long64_t nPositronEvents = 0;
    Long64_t nCoincidenceEvents = 0;
};

AcceptanceSummary ComputeAcceptance(TTree* generated, TTree* hits, int selectedVolumeID) {
    AcceptanceSummary s;
    if (generated) s.nGenerated = generated->GetEntries();

    if (!hits) return s;

    if (!HasBranch(hits, "eventID") || !HasBranch(hits, "pdg")) {
        std::cerr << "[ERROR] hits tree must contain eventID and pdg branches." << std::endl;
        return s;
    }

    Int_t eventID = -1;
    Int_t pdg = 0;
    Int_t volumeID = -999;

    hits->SetBranchStatus("*", 0);
    hits->SetBranchStatus("eventID", 1);
    hits->SetBranchStatus("pdg", 1);
    hits->SetBranchAddress("eventID", &eventID);
    hits->SetBranchAddress("pdg", &pdg);

    const bool useVolume = selectedVolumeID >= 0 && HasBranch(hits, "volumeID");
    if (useVolume) {
        hits->SetBranchStatus("volumeID", 1);
        hits->SetBranchAddress("volumeID", &volumeID);
    } else if (selectedVolumeID >= 0) {
        std::cerr << "[WARNING] volumeID branch not found. Ignoring volume selection." << std::endl;
    }

    std::set<int> electronEvents;
    std::set<int> positronEvents;

    const Long64_t n = hits->GetEntries();
    for (Long64_t i = 0; i < n; ++i) {
        hits->GetEntry(i);

        if (useVolume && volumeID != selectedVolumeID) continue;

        if (pdg == 11) {
            electronEvents.insert(eventID);
            ++s.nHitRowsSelected;
        } else if (pdg == -11) {
            positronEvents.insert(eventID);
            ++s.nHitRowsSelected;
        }
    }

    s.nElectronEvents = static_cast<Long64_t>(electronEvents.size());
    s.nPositronEvents = static_cast<Long64_t>(positronEvents.size());

    Long64_t nCoinc = 0;
    for (const auto& id : electronEvents) {
        if (positronEvents.count(id)) ++nCoinc;
    }
    s.nCoincidenceEvents = nCoinc;

    hits->SetBranchStatus("*", 1);
    return s;
}

void PrintAcceptance(const std::string& label, const AcceptanceSummary& s) {
    const double invN = (s.nGenerated > 0) ? 1.0 / static_cast<double>(s.nGenerated) : 0.0;

    std::cout << "\n=== " << label << " acceptance summary ===\n";
    std::cout << "Generated events             : " << s.nGenerated << "\n";
    std::cout << "Selected hit rows             : " << s.nHitRowsSelected << "\n";
    std::cout << "Events with detected e-       : " << s.nElectronEvents
              << "  efficiency = " << s.nElectronEvents * invN << "\n";
    std::cout << "Events with detected e+       : " << s.nPositronEvents
              << "  efficiency = " << s.nPositronEvents * invN << "\n";
    std::cout << "Events with e- AND e+         : " << s.nCoincidenceEvents
              << "  efficiency = " << s.nCoincidenceEvents * invN << "\n";
}

TH1D* MakeHistFromTree(TTree* tree,
                       const char* branchName,
                       const char* histName,
                       const char* title,
                       int nbins,
                       double xmin,
                       double xmax,
                       double scale = 1.0) {
    TH1D* h = new TH1D(histName, title, nbins, xmin, xmax);
    h->Sumw2();

    if (!tree) {
        std::cerr << "[WARNING] Cannot fill " << histName << ": null tree." << std::endl;
        return h;
    }

    if (!HasBranch(tree, branchName)) {
        std::cerr << "[WARNING] Branch '" << branchName << "' not found in tree '"
                  << tree->GetName() << "'. Empty histogram: " << histName << std::endl;
        return h;
    }

    Double_t x = 0.0;
    tree->SetBranchStatus("*", 0);
    tree->SetBranchStatus(branchName, 1);
    tree->SetBranchAddress(branchName, &x);

    const Long64_t n = tree->GetEntries();
    for (Long64_t i = 0; i < n; ++i) {
        tree->GetEntry(i);
        if (std::isfinite(x)) h->Fill(x);
    }

    tree->SetBranchStatus("*", 1);

    if (scale != 1.0) h->Scale(scale);
    return h;
}

void NormalizeToUnitArea(TH1D* h) {
    if (!h) return;
    const double integral = h->Integral("width");
    if (integral > 0) h->Scale(1.0 / integral);
}

void SaveOverlayPlot(TH1D* hSig,
                     TH1D* hBkg,
                     const std::string& canvasName,
                     const std::string& outPdf,
                     const std::string& xTitle,
                     bool normalize,
                     const std::string& labelSig = "signal",
                     const std::string& labelBkg = "background") {
    if (!hSig || !hBkg) return;

    std::unique_ptr<TH1D> s(dynamic_cast<TH1D*>(hSig->Clone((canvasName + "_sig_plot").c_str())));
    std::unique_ptr<TH1D> b(dynamic_cast<TH1D*>(hBkg->Clone((canvasName + "_bkg_plot").c_str())));

    if (normalize) {
        NormalizeToUnitArea(s.get());
        NormalizeToUnitArea(b.get());
    }

    TCanvas c(canvasName.c_str(), canvasName.c_str(), 900, 700);
    c.SetTicks(1, 1);

    s->SetLineWidth(3);
    b->SetLineWidth(3);
    s->SetLineColor(kBlue + 1);
    b->SetLineColor(kRed + 1);

    s->GetXaxis()->SetTitle(xTitle.c_str());
    s->GetYaxis()->SetTitle(normalize ? "normalized entries" : "entries");
    b->GetXaxis()->SetTitle(xTitle.c_str());
    b->GetYaxis()->SetTitle(normalize ? "normalized entries" : "entries");

    const double maxY = 1.25 * std::max(s->GetMaximum(), b->GetMaximum());
    s->SetMaximum(maxY > 0 ? maxY : 1.0);

    s->Draw("HIST");
    b->Draw("HIST SAME");

    TLegend leg(0.62, 0.72, 0.88, 0.88);
    leg.SetBorderSize(0);
    leg.SetFillStyle(0);
    leg.AddEntry(s.get(), labelSig.c_str(), "l");
    leg.AddEntry(b.get(), labelBkg.c_str(), "l");
    leg.Draw();

    c.SaveAs(outPdf.c_str());
}

TH1D* MakeSignalPlusBackground(TH1D* hSig, TH1D* hBkg, const char* name) {
    if (!hSig || !hBkg) return nullptr;
    TH1D* h = dynamic_cast<TH1D*>(hBkg->Clone(name));
    h->Add(hSig);
    h->SetLineColor(kBlack);
    h->SetLineWidth(3);
    return h;
}

TH1D* MakeSignificanceHist(TH1D* hSig, TH1D* hBkg, const char* name, const char* title) {
    if (!hSig || !hBkg) return nullptr;
    TH1D* h = dynamic_cast<TH1D*>(hSig->Clone(name));
    h->Reset("ICES");
    h->SetTitle(title);
    h->GetYaxis()->SetTitle("S / #sqrt{B}");
    h->SetLineColor(kBlack);
    h->SetLineWidth(3);

    for (int i = 1; i <= h->GetNbinsX(); ++i) {
        const double S = hSig->GetBinContent(i);
        const double B = hBkg->GetBinContent(i);
        h->SetBinContent(i, B > 0 ? S / std::sqrt(B) : 0.0);
        h->SetBinError(i, 0.0);
    }
    return h;
}

void SaveSinglePlot(TH1D* h, const std::string& canvasName, const std::string& outPdf, const std::string& xTitle) {
    if (!h) return;

    TCanvas c(canvasName.c_str(), canvasName.c_str(), 900, 700);
    c.SetTicks(1, 1);

    h->SetLineWidth(3);
    h->GetXaxis()->SetTitle(xTitle.c_str());
    h->Draw("HIST");
    c.SaveAs(outPdf.c_str());
}

} // namespace x17ana


void x17_full_analysis(
    const char* sigSampled = "sampled.root",
    const char* bkgSampled = "background_sampled.root",
    const char* sigIdeal = "analysis_hits.root",
    const char* bkgIdeal = "background_analysis_hits.root",
    const char* sigReco = "analysis_hits_detector_effects.root",
    const char* bkgReco = "background_analysis_hits_detector_effects.root",
    const char* outRoot = "x17_final_analysis.root",
    const char* outDir = "plots",
    int selectedVolumeID = 0,
    double signalScale = 1.0,
    double backgroundScale = 1.0
) {
    using namespace x17ana;

    gStyle->SetOptStat(0);
    gSystem->mkdir(outDir, kTRUE);

    std::unique_ptr<TFile> fSigSampled(TFile::Open(sigSampled, "READ"));
    std::unique_ptr<TFile> fBkgSampled(TFile::Open(bkgSampled, "READ"));
    std::unique_ptr<TFile> fSigIdeal(TFile::Open(sigIdeal, "READ"));
    std::unique_ptr<TFile> fBkgIdeal(TFile::Open(bkgIdeal, "READ"));
    std::unique_ptr<TFile> fSigReco(TFile::Open(sigReco, "READ"));
    std::unique_ptr<TFile> fBkgReco(TFile::Open(bkgReco, "READ"));

    TTree* sigGen = GetTreeChecked(fSigSampled.get(), "generated", sigSampled);
    TTree* sigHits = GetTreeChecked(fSigSampled.get(), "hits", sigSampled);
    TTree* bkgGen = GetTreeChecked(fBkgSampled.get(), "generated", bkgSampled);
    TTree* bkgHits = GetTreeChecked(fBkgSampled.get(), "hits", bkgSampled);

    TTree* sigDetected = GetTreeChecked(fSigIdeal.get(), "detected", sigIdeal);
    TTree* bkgDetected = GetTreeChecked(fBkgIdeal.get(), "detected", bkgIdeal);

    TTree* sigDetEff = GetTreeChecked(fSigReco.get(), "detected_detector_effects", sigReco);
    TTree* bkgDetEff = GetTreeChecked(fBkgReco.get(), "detected_detector_effects", bkgReco);

    std::cout << "\n=== X17 full analysis ===\n";
    std::cout << "Signal sampled file          : " << sigSampled << "\n";
    std::cout << "Background sampled file      : " << bkgSampled << "\n";
    std::cout << "Signal ideal analysis file   : " << sigIdeal << "\n";
    std::cout << "Background ideal file        : " << bkgIdeal << "\n";
    std::cout << "Signal detector-effects file : " << sigReco << "\n";
    std::cout << "Background detector file     : " << bkgReco << "\n";
    std::cout << "Selected volumeID            : " << selectedVolumeID
              << "  (-1 means any volume)\n";
    std::cout << "Signal scale                 : " << signalScale << "\n";
    std::cout << "Background scale             : " << backgroundScale << "\n";

    AcceptanceSummary sigAcc = ComputeAcceptance(sigGen, sigHits, selectedVolumeID);
    AcceptanceSummary bkgAcc = ComputeAcceptance(bkgGen, bkgHits, selectedVolumeID);

    PrintAcceptance("SIGNAL", sigAcc);
    PrintAcceptance("BACKGROUND", bkgAcc);

    std::cout << "\n=== Tree entries ===\n";
    std::cout << "signal detected ideal        : " << (sigDetected ? sigDetected->GetEntries() : 0) << "\n";
    std::cout << "background detected ideal    : " << (bkgDetected ? bkgDetected->GetEntries() : 0) << "\n";
    std::cout << "signal detector effects      : " << (sigDetEff ? sigDetEff->GetEntries() : 0) << "\n";
    std::cout << "background detector effects  : " << (bkgDetEff ? bkgDetEff->GetEntries() : 0) << "\n";

    std::unique_ptr<TFile> fout(TFile::Open(outRoot, "RECREATE"));
    if (!fout || fout->IsZombie()) {
        std::cerr << "[ERROR] Cannot create output file: " << outRoot << std::endl;
        return;
    }

    // Generated level.
    TH1D* hSigGenThetaEE = MakeHistFromTree(sigGen, "thetaEE_txt_deg", "hSigGenThetaEE",
                                            "Generated opening angle;#theta_{ee}^{gen} [deg];entries",
                                            90, 0, 180, signalScale);
    TH1D* hBkgGenThetaEE = MakeHistFromTree(bkgGen, "thetaEE_txt_deg", "hBkgGenThetaEE",
                                            "Generated opening angle;#theta_{ee}^{gen} [deg];entries",
                                            90, 0, 180, backgroundScale);

    // Ideal detected level.
    TH1D* hSigHitThetaEE = MakeHistFromTree(sigDetected, "thetaEE_hit_deg", "hSigHitThetaEE",
                                            "Ideal detected opening angle;#theta_{ee}^{hit} [deg];entries",
                                            90, 0, 180, signalScale);
    TH1D* hBkgHitThetaEE = MakeHistFromTree(bkgDetected, "thetaEE_hit_deg", "hBkgHitThetaEE",
                                            "Ideal detected opening angle;#theta_{ee}^{hit} [deg];entries",
                                            90, 0, 180, backgroundScale);

    TH1D* hSigHitMassEE = MakeHistFromTree(sigDetected, "massEE_hit_MeV", "hSigHitMassEE",
                                           "Ideal detected invariant mass;m_{ee}^{hit} [MeV/c^{2}];entries",
                                           80, 0, 25, signalScale);
    TH1D* hBkgHitMassEE = MakeHistFromTree(bkgDetected, "massEE_hit_MeV", "hBkgHitMassEE",
                                           "Ideal detected invariant mass;m_{ee}^{hit} [MeV/c^{2}];entries",
                                           80, 0, 25, backgroundScale);

    // Reco detector-effects level.
    TH1D* hSigRecoThetaEE = MakeHistFromTree(sigDetEff, "thetaEE_reco_deg", "hSigRecoThetaEE",
                                             "Reco opening angle;#theta_{ee}^{reco} [deg];entries",
                                             90, 0, 180, signalScale);
    TH1D* hBkgRecoThetaEE = MakeHistFromTree(bkgDetEff, "thetaEE_reco_deg", "hBkgRecoThetaEE",
                                             "Reco opening angle;#theta_{ee}^{reco} [deg];entries",
                                             90, 0, 180, backgroundScale);

    TH1D* hSigRecoMassEE = MakeHistFromTree(sigDetEff, "massEE_reco_MeV", "hSigRecoMassEE",
                                            "Reco invariant mass;m_{ee}^{reco} [MeV/c^{2}];entries",
                                            80, 0, 25, signalScale);
    TH1D* hBkgRecoMassEE = MakeHistFromTree(bkgDetEff, "massEE_reco_MeV", "hBkgRecoMassEE",
                                            "Reco invariant mass;m_{ee}^{reco} [MeV/c^{2}];entries",
                                            80, 0, 25, backgroundScale);

    TH1D* hSigRecoEnergyEE = MakeHistFromTree(sigDetEff, "energyEE_reco_MeV", "hSigRecoEnergyEE",
                                              "Reco pair energy;E_{ee}^{reco} [MeV];entries",
                                              80, 0, 25, signalScale);
    TH1D* hBkgRecoEnergyEE = MakeHistFromTree(bkgDetEff, "energyEE_reco_MeV", "hBkgRecoEnergyEE",
                                              "Reco pair energy;E_{ee}^{reco} [MeV];entries",
                                              80, 0, 25, backgroundScale);

    // Signal + background and simple per-bin significance.
    TH1D* hRecoThetaEE_SplusB = MakeSignalPlusBackground(hSigRecoThetaEE, hBkgRecoThetaEE, "hRecoThetaEE_SplusB");
    TH1D* hRecoMassEE_SplusB  = MakeSignalPlusBackground(hSigRecoMassEE,  hBkgRecoMassEE,  "hRecoMassEE_SplusB");

    TH1D* hSignificanceThetaEE = MakeSignificanceHist(hSigRecoThetaEE, hBkgRecoThetaEE,
                                                      "hSignificanceThetaEE",
                                                      "Per-bin sensitivity in #theta_{ee}^{reco};#theta_{ee}^{reco} [deg];S/#sqrt{B}");
    TH1D* hSignificanceMassEE = MakeSignificanceHist(hSigRecoMassEE, hBkgRecoMassEE,
                                                     "hSignificanceMassEE",
                                                     "Per-bin sensitivity in m_{ee}^{reco};m_{ee}^{reco} [MeV/c^{2}];S/#sqrt{B}");

    // Cutflow-like summary histogram.
    TH1D* hSummary = new TH1D("hSummary", "Analysis summary;;events", 8, 0.5, 8.5);
    hSummary->GetXaxis()->SetBinLabel(1, "sig gen");
    hSummary->GetXaxis()->SetBinLabel(2, "sig e-");
    hSummary->GetXaxis()->SetBinLabel(3, "sig e+");
    hSummary->GetXaxis()->SetBinLabel(4, "sig pair");
    hSummary->GetXaxis()->SetBinLabel(5, "bkg gen");
    hSummary->GetXaxis()->SetBinLabel(6, "bkg e-");
    hSummary->GetXaxis()->SetBinLabel(7, "bkg e+");
    hSummary->GetXaxis()->SetBinLabel(8, "bkg pair");
    hSummary->SetBinContent(1, sigAcc.nGenerated);
    hSummary->SetBinContent(2, sigAcc.nElectronEvents);
    hSummary->SetBinContent(3, sigAcc.nPositronEvents);
    hSummary->SetBinContent(4, sigAcc.nCoincidenceEvents);
    hSummary->SetBinContent(5, bkgAcc.nGenerated);
    hSummary->SetBinContent(6, bkgAcc.nElectronEvents);
    hSummary->SetBinContent(7, bkgAcc.nPositronEvents);
    hSummary->SetBinContent(8, bkgAcc.nCoincidenceEvents);

    // Write all histograms.
    fout->cd();

    hSummary->Write();

    hSigGenThetaEE->Write();
    hBkgGenThetaEE->Write();

    hSigHitThetaEE->Write();
    hBkgHitThetaEE->Write();
    hSigHitMassEE->Write();
    hBkgHitMassEE->Write();

    hSigRecoThetaEE->Write();
    hBkgRecoThetaEE->Write();
    hSigRecoMassEE->Write();
    hBkgRecoMassEE->Write();
    hSigRecoEnergyEE->Write();
    hBkgRecoEnergyEE->Write();

    if (hRecoThetaEE_SplusB) hRecoThetaEE_SplusB->Write();
    if (hRecoMassEE_SplusB) hRecoMassEE_SplusB->Write();
    if (hSignificanceThetaEE) hSignificanceThetaEE->Write();
    if (hSignificanceMassEE) hSignificanceMassEE->Write();

    fout->Close();

    const std::string dir(outDir);

    SaveOverlayPlot(hSigGenThetaEE, hBkgGenThetaEE,
                    "cGenThetaEE",
                    dir + "/generated_thetaEE_signal_vs_background.pdf",
                    "#theta_{ee}^{gen} [deg]",
                    true);

    SaveOverlayPlot(hSigHitThetaEE, hBkgHitThetaEE,
                    "cHitThetaEE",
                    dir + "/ideal_detected_thetaEE_signal_vs_background.pdf",
                    "#theta_{ee}^{hit} [deg]",
                    true);

    SaveOverlayPlot(hSigHitMassEE, hBkgHitMassEE,
                    "cHitMassEE",
                    dir + "/ideal_detected_massEE_signal_vs_background.pdf",
                    "m_{ee}^{hit} [MeV/c^{2}]",
                    true);

    SaveOverlayPlot(hSigRecoThetaEE, hBkgRecoThetaEE,
                    "cRecoThetaEE",
                    dir + "/reco_thetaEE_signal_vs_background.pdf",
                    "#theta_{ee}^{reco} [deg]",
                    true);

    SaveOverlayPlot(hSigRecoMassEE, hBkgRecoMassEE,
                    "cRecoMassEE",
                    dir + "/reco_massEE_signal_vs_background.pdf",
                    "m_{ee}^{reco} [MeV/c^{2}]",
                    true);

    SaveOverlayPlot(hSigRecoEnergyEE, hBkgRecoEnergyEE,
                    "cRecoEnergyEE",
                    dir + "/reco_energyEE_signal_vs_background.pdf",
                    "E_{ee}^{reco} [MeV]",
                    true);

    SaveSinglePlot(hSignificanceThetaEE,
                   "cSignificanceThetaEE",
                   dir + "/significance_thetaEE.pdf",
                   "#theta_{ee}^{reco} [deg]");

    SaveSinglePlot(hSignificanceMassEE,
                   "cSignificanceMassEE",
                   dir + "/significance_massEE.pdf",
                   "m_{ee}^{reco} [MeV/c^{2}]");

    std::cout << "\n=== Outputs ===\n";
    std::cout << "Output ROOT file : " << outRoot << "\n";
    std::cout << "PDF directory    : " << outDir << "\n";
    std::cout << "\nDone.\n";
}
